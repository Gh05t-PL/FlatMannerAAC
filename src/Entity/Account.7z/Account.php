<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="App\Repository\AccountRepository")
 * @ORM\Table(name="accounts")
 */
class Account
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    public $id;

    /** @ORM\Column(type="string", length=32) */
    public $name;

    /** @ORM\Column(type="string", length=255) */
    public $password;

    /** @ORM\Column(type="integer", length=11) */
    public $premdays;

    /** @ORM\Column(type="integer", length=10) */
    public $lastday;

    /** @ORM\Column(type="string", length=255) */
    public $email;

    /** @ORM\Column(type="string", length=20) */
    public $key;

    /** @ORM\Column(type="integer", length=1) */
    public $blocked;
    
    /** @ORM\Column(type="integer", length=11) */
    public $warnings;

    /** @ORM\Column(type="integer", length=11) */
    public $group_id;
}
